param([ValidateSet('install','uninstall')][string]$Mode='install', [string]$GameExe=(Join-Path $PSScriptRoot 'Lost Wiki Kozlovka.exe'))
$ErrorActionPreference='Stop'
try {
    Add-Type -Path (Join-Path $PSScriptRoot 'PatchCore.cs')
    $GameExe=[IO.Path]::GetFullPath($GameExe)
    $backup=$GameExe+'.zh-v12.original.bak'
    $receipt=$GameExe+'.zh-v12.json'
    $temp=$GameExe+'.zh-v12.tmp'
    if(-not [IO.File]::Exists($GameExe)) { throw 'Game EXE not found. Copy this entire patch folder contents into the game folder first.' }
    $original=[IO.File]::ReadAllBytes($GameExe)
    $originalHash=[KozlovkaPatch]::Hash($original)
    if($Mode -eq 'uninstall') {
        if(-not [IO.File]::Exists($receipt) -or -not [IO.File]::Exists($backup)) { throw 'Matching v1.2 backup and receipt not found.' }
        $state=Get-Content -LiteralPath $receipt -Raw | ConvertFrom-Json
        if($originalHash -ne $state.patched_sha256) { throw 'Game EXE has changed since installation. Refusing to overwrite a game update. Use Steam Verify Integrity to restore official files.' }
        $restore=[IO.File]::ReadAllBytes($backup)
        if([KozlovkaPatch]::Hash($restore) -ne $state.original_sha256) { throw 'Backup checksum mismatch.' }
        if([IO.File]::Exists($temp)) { throw 'Temporary file already exists. Inspect it before retrying.' }
        [IO.File]::WriteAllBytes($temp,$restore)
        $removed=$GameExe+'.zh-v12.removed'
        if([IO.File]::Exists($removed)) { throw 'Previous uninstall recovery file exists.' }
        [IO.File]::Move($GameExe,$removed)
        try { [IO.File]::Move($temp,$GameExe) } catch { [IO.File]::Move($removed,$GameExe); throw }
        [IO.File]::Delete($removed)
        [IO.File]::Delete($receipt)
        [IO.File]::Delete($backup)
        Write-Host 'Uninstalled. The exact original EXE has been restored.'
        exit 0
    }
    $manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $pack=[KozlovkaPatch]::Read($original)
    $existing=@{}; foreach($e in $pack.Files) { $existing[$e.Path]=$e.Data }
    $replacements=New-Object 'System.Collections.Generic.Dictionary[string,byte[]]'
    $allPatched=$true
    foreach($r in $manifest.resources) {
        $data=[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $r.payload))
        if([KozlovkaPatch]::Hash($data) -ne $r.patched_sha256) { throw "Patch payload is damaged: $($r.path)" }
        $replacements.Add($r.path,$data)
        if(-not $existing.ContainsKey($r.path) -or [KozlovkaPatch]::Hash($existing[$r.path]) -ne $r.patched_sha256) { $allPatched=$false }
    }
    if($allPatched) { Write-Host 'This patch is already installed. No changes made.'; exit 0 }
    foreach($r in $manifest.resources) {
        if($null -eq $r.original_sha256) {
            if($existing.ContainsKey($r.path)) { throw "Unexpected existing resource: $($r.path). Restore official game files first." }
        } elseif(-not $existing.ContainsKey($r.path) -or [KozlovkaPatch]::Hash($existing[$r.path]) -ne $r.original_sha256) {
            throw "Resource version mismatch: $($r.path). No changes made. If running an older Chinese patch, use Steam Verify Integrity first; if this is a newer official build, send this resource name for a compatibility update."
        }
    }
    if([IO.File]::Exists($backup) -or [IO.File]::Exists($receipt) -or [IO.File]::Exists($temp)) { throw 'An earlier backup, receipt or temporary file exists. Preserve these files and resolve the previous installation before retrying.' }
    $patched=[KozlovkaPatch]::Build($original,$pack,$replacements)
    $patchedHash=[KozlovkaPatch]::Hash($patched)
    [IO.File]::WriteAllBytes($temp,$patched)
    if([KozlovkaPatch]::Hash([IO.File]::ReadAllBytes($temp)) -ne $patchedHash) { throw 'Written file verification failed.' }
    if([KozlovkaPatch]::Hash([IO.File]::ReadAllBytes($GameExe)) -ne $originalHash) { throw 'Game changed while preparing patch. Installation cancelled.' }
    # Keep the original intact under its backup name; roll back if the second rename fails.
    @{version=$manifest.version;original_sha256=$originalHash;patched_sha256=$patchedHash} | ConvertTo-Json | Set-Content -LiteralPath $receipt -Encoding UTF8
    [IO.File]::Move($GameExe,$backup)
    try { [IO.File]::Move($temp,$GameExe) } catch { [IO.File]::Move($backup,$GameExe); throw }
    Write-Host 'Installed v1.2 BETA. Start the game and select Simplified Chinese.'
    Write-Host 'Original EXE backup saved. Use uninstall_beta.bat to restore it.'
} catch {
    Write-Host ('FAILED: '+$_.Exception.Message) -ForegroundColor Red
    exit 1
}
