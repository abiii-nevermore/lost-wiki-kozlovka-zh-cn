@echo off
chcp 65001 >nul
setlocal EnableExtensions
pushd "%~dp0"
title Lost Wiki: Kozlovka 简体中文补丁安装程序

set "GAME=Lost Wiki Kozlovka.exe"
set "BACKUP=Lost Wiki Kozlovka.exe.bak"
set "PATCH=Lost_Wiki_Kozlovka_zh_CN_v1.0.xdelta"
set "PATCHER=xdelta3.exe"
set "TEMP=Lost Wiki Kozlovka.exe.zh_CN_tmp"

echo.
echo ============================================================
echo        Lost Wiki: Kozlovka 简体中文补丁 v1.0
echo ============================================================
echo.

if not exist "%PATCHER%" goto :missing_patcher
if not exist "%PATCH%" goto :missing_patch
if not exist "%GAME%" goto :missing_game

if not exist "%BACKUP%" (
    echo [1/3] 正在备份原版游戏文件……
    copy /y "%GAME%" "%BACKUP%" >nul
    if errorlevel 1 goto :write_error
) else (
    echo [1/3] 已找到原版备份，跳过备份。
)

if exist "%TEMP%" del /q "%TEMP%" >nul 2>&1

echo [2/3] 正在应用汉化补丁……
"%PATCHER%" -d -f -s "%BACKUP%" "%PATCH%" "%TEMP%" >nul 2>&1
if errorlevel 1 goto :patch_error
if not exist "%TEMP%" goto :patch_error

echo [3/3] 正在替换游戏文件……
move /y "%TEMP%" "%GAME%" >nul
if errorlevel 1 goto :write_error

echo.
echo ============================================================
echo 安装完成！现在可以照常通过 Steam 启动游戏。
echo 原版备份已保存为：%BACKUP%
echo ============================================================
echo.
goto :finish

:missing_patcher
echo [错误] 当前文件夹中没有找到 %PATCHER%。
echo 请将压缩包内的全部文件一起解压到游戏目录后再运行。
goto :failed

:missing_patch
echo [错误] 当前文件夹中没有找到 %PATCH%。
echo 请将压缩包内的全部文件一起解压到游戏目录后再运行。
goto :failed

:missing_game
echo [错误] 当前文件夹中没有找到 %GAME%。
echo 请把补丁包中的全部文件放进原版游戏目录。
echo 可在 Steam 中右键游戏，选择“管理”→“浏览本地文件”。
goto :failed

:patch_error
if exist "%TEMP%" del /q "%TEMP%" >nul 2>&1
echo [错误] 补丁无法应用，游戏文件未被替换。
echo.
echo 常见原因：
echo 1. 原游戏版本与本补丁要求的版本不一致；
echo 2. %BACKUP% 不是干净的原版文件；
echo 3. 游戏更新后仍保留着旧版本备份。
echo.
echo 解决方法：在 Steam 中验证游戏文件完整性，删除旧的
echo %BACKUP%，然后重新运行本脚本。
goto :failed

:write_error
if exist "%TEMP%" del /q "%TEMP%" >nul 2>&1
echo [错误] 无法写入游戏目录。
echo 请先关闭游戏；仍然失败时，请右键本脚本并选择“以管理员身份运行”。
goto :failed

:failed
echo.
echo 安装未完成。
echo.

:finish
popd
pause
exit /b
