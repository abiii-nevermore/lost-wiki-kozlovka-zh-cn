using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Security.Cryptography;

public static class KozlovkaPatch {
 public class Entry { public string Path; public byte[] Data; }
 public class Pack { public int Start; public byte[] Header; public List<Entry> Files = new List<Entry>(); }
 public static string Hash(byte[] data) { using(var h=SHA256.Create()) return BitConverter.ToString(h.ComputeHash(data)).Replace("-", "").ToLowerInvariant(); }
 static byte[] MD5Sum(byte[] data) { using(var h=MD5.Create()) return h.ComputeHash(data); }
 static void Require(bool b,string message) { if(!b) throw new InvalidDataException(message); }
 static bool Equal(byte[] a,byte[] b) { return Convert.ToBase64String(a)==Convert.ToBase64String(b); }
 public static Pack Read(byte[] b) {
  Require(b.Length>112,"File too small.");
  using(var r=new BinaryReader(new MemoryStream(b))) {
   r.BaseStream.Position=b.Length-12; ulong size=r.ReadUInt64(); Require(r.ReadUInt32()==0x43504447,"No embedded PCK footer.");
   Require(size<=(ulong)b.Length-12,"Invalid PCK size.");
   var p=new Pack();p.Start=checked(b.Length-12-(int)size);r.BaseStream.Position=p.Start;
   Require(r.ReadUInt32()==0x43504447 && r.ReadUInt32()==2,"Unsupported PCK version.");
   Require(r.ReadUInt32()==4,"Unsupported engine major version.");r.ReadUInt32();r.ReadUInt32();
   Require(r.ReadUInt32()==2,"Unsupported PCK flags (encrypted or absolute offsets).");ulong baseOffset=r.ReadUInt64();
   r.BaseStream.Position=p.Start;p.Header=r.ReadBytes(100);r.BaseStream.Position=p.Start+96;
   uint count=r.ReadUInt32();Require(count<100000,"Invalid resource count.");var names=new HashSet<string>();
   for(uint i=0;i<count;i++) {
    uint n=r.ReadUInt32();Require(n>0 && n<32768,"Invalid resource path.");
    string path=Encoding.UTF8.GetString(r.ReadBytes((int)n)).TrimEnd('\0');Require(names.Add(path),"Duplicate resource.");
    ulong off=r.ReadUInt64(),len=r.ReadUInt64();byte[] digest=r.ReadBytes(16);Require(r.ReadUInt32()==0,"Unsupported resource flags.");
    Require(len<=int.MaxValue && off<=(ulong)b.Length && baseOffset<=(ulong)b.Length,"Invalid resource bounds.");
    ulong absolute=(ulong)p.Start+baseOffset+off;Require(absolute+len<=(ulong)b.Length-12,"Resource exceeds PCK.");
    byte[] data=new byte[(int)len];Buffer.BlockCopy(b,(int)absolute,data,0,data.Length);Require(Equal(MD5Sum(data),digest),"Resource checksum failed: "+path);
    p.Files.Add(new Entry{Path=path,Data=data});
   }
   return p;
  }
 }
 static long Align(long n) { return (n+15)&~15L; }
 public static byte[] Build(byte[] original,Pack p,Dictionary<string,byte[]> replacements) {
  var files=new List<Entry>();var remaining=new Dictionary<string,byte[]>(replacements);
  foreach(var e in p.Files) { byte[] data; if(remaining.TryGetValue(e.Path,out data)) {files.Add(new Entry{Path=e.Path,Data=data});remaining.Remove(e.Path);} else files.Add(e); }
  foreach(var e in remaining) files.Add(new Entry{Path=e.Key,Data=e.Value});
  long indexSize=100;foreach(var e in files) indexSize+=4+((Encoding.UTF8.GetByteCount(e.Path)+3)&~3)+36;
  long dataBase=Align(indexSize),off=0;
  using(var stream=new MemoryStream()) using(var w=new BinaryWriter(stream)) {
   w.Write(original,0,p.Start);w.Write(p.Header);stream.Position=p.Start+24;w.Write((ulong)dataBase);stream.Position=p.Start+96;w.Write(files.Count);
   foreach(var e in files) {byte[] name=Encoding.UTF8.GetBytes(e.Path);int padded=(name.Length+3)&~3;w.Write(padded);w.Write(name);w.Write(new byte[padded-name.Length]);w.Write((ulong)off);w.Write((ulong)e.Data.Length);w.Write(MD5Sum(e.Data));w.Write(0);off=Align(off+e.Data.Length);}
   stream.SetLength(p.Start+dataBase+off);off=0;
   foreach(var e in files) {stream.Position=p.Start+dataBase+off;w.Write(e.Data);off=Align(off+e.Data.Length);}
   stream.Position=stream.Length;w.Write((ulong)(dataBase+off));w.Write(0x43504447u);
   byte[] result=stream.ToArray();
   int pe=BitConverter.ToInt32(result,60);Require(pe>=0 && pe+24< p.Start,"Invalid PE header.");
   Require(BitConverter.ToUInt32(result,pe)==0x4550,"Invalid PE signature.");int sections=BitConverter.ToUInt16(result,pe+6),header=pe+24+BitConverter.ToUInt16(result,pe+20);bool found=false;
   for(int i=0;i<sections;i++) {int s=header+i*40;Require(s+40<=p.Start,"Invalid PE sections.");if(Encoding.ASCII.GetString(result,s,8).TrimEnd('\0')=="pck") {Require(BitConverter.ToUInt32(result,s+20)==p.Start,"Unexpected PCK section offset.");Buffer.BlockCopy(BitConverter.GetBytes((uint)(result.Length-p.Start)),0,result,s+16,4);found=true;}}
   Require(found,"No PE PCK section.");
   // Verify every written resource before any game file is changed.
   Pack check=Read(result);Require(check.Files.Count==files.Count,"Output resource count mismatch.");
   for(int i=0;i<files.Count;i++) Require(check.Files[i].Path==files[i].Path && Equal(check.Files[i].Data,files[i].Data),"Output validation failed.");
   return result;
  }
 }
}
