@echo off
chcp 65001 >nul
setlocal EnableExtensions
pushd "%~dp0"
title Lost Wiki: Kozlovka 简体中文补丁卸载程序

set "GAME=Lost Wiki Kozlovka.exe"
set "BACKUP=Lost Wiki Kozlovka.exe.bak"

echo.
echo ============================================================
echo        Lost Wiki: Kozlovka 简体中文补丁卸载程序
echo ============================================================
echo.

if not exist "%BACKUP%" goto :missing_backup

echo 正在恢复原版游戏文件……
copy /y "%BACKUP%" "%GAME%" >nul
if errorlevel 1 goto :write_error

echo.
echo 卸载完成，游戏已恢复为安装汉化前的版本。
echo 备份文件仍予保留，确认游戏正常后可手动删除：
echo %BACKUP%
echo.
goto :finish

:missing_backup
echo [错误] 没有找到原版备份：%BACKUP%
echo 如果游戏文件有问题，请通过 Steam 验证游戏文件完整性。
echo.
goto :finish

:write_error
echo [错误] 无法恢复游戏文件。
echo 请先关闭游戏；仍然失败时，请右键本脚本并选择“以管理员身份运行”。
echo.

:finish
popd
pause
exit /b
